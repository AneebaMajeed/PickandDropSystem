<?php
session_start();
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'aoa');
 
/* Attempt to connect to MySQL database */
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
$start=$start_err=$dest=$dest_err=$seats=$seats_err=$vehicle=$vehicle_err=$time=$time_err=$fare=$fare_err="";
if(isset($_POST['txtbutton']))
{
    if(empty(trim($_POST["start"]))){
        $start_err = "*Please enter a Pickup point.";
    } else{
        $start= trim($_POST["start"]);
    }
    if(empty(trim($_POST["dest"]))){
        $dest_err = "*Please enter a destination.";
    } else{
        $dest = trim($_POST["dest"]);
    }
    if (!isset($_POST['seats'])){
        $seats_err = "*Please enter Seats.";
   // if(@$_POST["seats"].checked== null){
   //     $seats_err = "*Please enter Seats.";
    } else{
        $seats = trim($_POST["seats"]);
    }
    if(empty(trim($_POST["vehicle"]))){
        $vehicle_err = "*Please enter Vehicle.";
    } else{
        $vehicle = trim($_POST["vehicle"]);
    }
    if(empty(trim($_POST["fare"]))){
        $fare_err = "*Please enter  fare.";
    } else{
        $fare = trim($_POST["fare"]);
    }
    if(empty(trim($_POST["time"]))){
        $time_err = "*Please enter a time.";
    } else{
        //$time = trim($_POST["time"]);
        $time = date('h:i:s a', strtotime($_POST['time']));
    }
  //$start=$_POST["start"];
  //$dest=$_POST["dest"];
  //$seats=$_POST["seats"];
  //$vehicle=$_POST["vehicle"];
  //$time=$_POST["time"];
  //$fare=$_POST["fare"];
  $username =$_SESSION["username"];
  if(empty($start_err) && empty($dest_err) && empty($seats_err) && empty($vehicle_err) && empty($fare_err) && empty($time_err)){
  $link->query("insert into driver(username,start,destination,seats,vehicle,fare,time) values('$username', '$start','$dest','$seats','$vehicle','$fare','$time')");
  if(!$link) 
  { echo mysqli_error(); }


  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://fonts.googleapis.com/css?family=Literata&display=swap" rel="stylesheet">
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <title>Driver </title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <!-- Bootstrap -->
  <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">-->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
    integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.4.1.js" integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
    crossorigin="anonymous"></script>
</head>
<script>
  /*  function validName(){
            var n=document.getElementById("pickUp").value;
            var flag=false;
          
            for(let i=0;i<n.length;i++)
            {
                var nm=n.charCodeAt(i);
            if(!(((nm>64 && nm<91) || (nm>94 && nm<123)) || (nm==32)))
            {
                 flag=true; 
            }
            
            }
            if(flag==true){
               
              var h=document.getElementById("errormessage1");
            
             h.innerHTML="Invalid Input!! Enter only letters!";
              
              document.getElementById("pickUp").focus();
              

            }
            else
            {
                 var h=document.getElementById("errormessage1");
                
                 h.innerHTML="";
            }

        } 
        function validdest(){
            var n=document.getElementById("drop1").value;
            var flag=false;
          
            for(let i=0;i<n.length;i++)
            {
                var nm=n.charCodeAt(i);
            if(!(((nm>64 && nm<91) || (nm>94 && nm<123)) || (nm==32)))
            {
                 flag=true; 
            }
            
            }
            if(flag==true){
               
              var h=document.getElementById("errormessage2");
              
             h.innerHTML="Invalid Input!! Enter only letters!";
              
              document.getElementById("drop1").focus();
              

            }
            else
            {
                 var h=document.getElementById("errormessage2");
                
                 h.innerHTML="";
            }

        } */
</script>
<style>
  #btn8 {
    font-family: "Times New Roman", Times, serif;
    position: absolute;
    bottom: 370px;
    left: 800px;
    font-size: 20px;

  }

  #style {
    font-family: "Times New Roman", Times, serif;
    height: 70px;
    background-color: darkblue;
  }

  .rights {
    list-style-type: none;
    margin: 0;
    padding: 0;
    width: 200px;
    height: 632px;
    background-color: darkblue;
  }

  #btn2 {
    font-family: "Times New Roman", Times, serif;
    font-size: 20px;
    margin-left: 8px;
    margin-right: 20px;
    width: 180px;
    margin-top: 7px;
    border-radius: 10px;
    height: 50px;
    border: 1px solid darkblue;

  }

  Button a:hover {

    color: white;
  }

  #btnAdd {
    font-family: "Times New Roman", Times, serif;
    position: absolute;
    bottom: 170px;
    left: 800px;
    font-size: 20px;

  }

  #errormessage1 {
    font-family: "Times New Roman", Times, serif;
    font-size: 15px;
    color: red;
    position: absolute;
    left: 510px;
    bottom: 532px;
    display: relative;

  }

  #errormessage2 {
    font-family: "Times New Roman", Times, serif;
    font-size: 15px;
    color: red;
    position: absolute;
    left: 510px;
    bottom: 480px;
    display: relative;
  }

  #errormessage3 {
    font-family: "Times New Roman", Times, serif;
    font-size: 15px;
    color: red;
    position: absolute;
    left: 510px;
    bottom: 420px;
    display: relative;

  }


  th {
    background-color: darkblue;
    color: white;
  }

  tr:nth-child(even) {
    background-color: lightblue
  }

  #table {
    font-family: "Times New Roman", Times, serif;
    position: absolute;
    bottom: 100px;
    left: 260px;
    width: 1000px;
    border: 4px;

  }


  #logo {
    background-image: url("./images/images.jpg");
    background-repeat: no-repeat;
    background-size: 65px;
    border: 1px solid blue;
    position: absolute;
    top: 10px;
    left: 19px;
    width: 67px;
    height: 50px;

  }

  #logo1 {
    background-image: url("./images/download1.jpg");
    background-repeat: no-repeat;
    background-size: 70px;
    border: 1px solid white;
    position: absolute;
    top: 70px;
    left: 1210px;
    width: 100px;
    height: 100px;

  }

  #btn2 {
    background-color: lightskyblue;
  }

  li a:hover {
    color: white;
  }

  .navbar-light {
    background-color: darkblue;
    color: white;
  }

  .brand-logo {
    font-size: 30px;
  }

  #col {
    margin-right: 10px;
    font-size: 20px;
  }


  #Sec {
    font-family: "Times New Roman", Times, serif;
    font-size: 25px;
    position: absolute;
    bottom: 500px;
    left: 300px;
  }

  #Sec1 {
    font-family: "Times New Roman", Times, serif;
    font-size: 25px;
    position: absolute;
    bottom: 440px;
    left: 300px;
  }


  #Sec2 {
    font-family: "Times New Roman", Times, serif;
    font-size: 25px;
    position: absolute;
    bottom: 390px;
    left: 300px;
  }

  #Sec3 {
    font-family: "Times New Roman", Times, serif;
    font-size: 25px;
    position: absolute;
    bottom: 340px;
    left: 300px;
  }

  #Sec4 {
    font-family: "Times New Roman", Times, serif;
    font-size: 25px;
    position: absolute;
    bottom: 290px;
    left: 300px;
  }

  #Sec5 {
    font-family: "Times New Roman", Times, serif;
    font-size: 25px;
    position: absolute;
    bottom: 240px;
    left: 300px;
  }





  #pickUp {

    font-family: "Times New Roman", Times, serif;
    position: absolute;
    bottom: 500px;
    left: 510px;
    width: 700px;
    height: 30px;

  }

  #drop1 {

font-family: "Times New Roman", Times, serif;
position: absolute;
bottom: 440px;
left: 500px;
width: 700px;
height: 30px;
}

  #drop2 {
    position: absolute;

    bottom: 400px;
    left: 600px;
  }


  #drop3 {
    position: absolute;

    bottom: 400px;
    left: 700px;
  }

  #drop4 {
    position: absolute;

    bottom: 400px;
    left: 800px;
  }

  #drop5 {
    position: absolute;

    bottom: 400px;
    left: 900px;
  }


  #drop6 {

font-family: "Times New Roman", Times, serif;
position: absolute;
bottom: 340px;
left: 500px;
width: 700px;
height: 30px;
}

  #drop7 {
    position: absolute;
    width: 700px;
    height: 30px;
    bottom: 290px;
    left: 500px;
  }

  #drop8 {
    position: absolute;
    width: 700px;
    height: 30px;
    bottom: 240px;
    left: 500px;
  }


  #one {
      font-family: "Times New Roman", Times, serif;
      font-size:25px;
    position: absolute;
    bottom: 390px;
    left: 625px;
  }

  #two {
    font-family: "Times New Roman", Times, serif;
      font-size:25px;
    position: absolute;
    bottom: 390px;
    left: 725px;
  }

  #three {
    font-family: "Times New Roman", Times, serif;
      font-size:25px;
    position: absolute;
    bottom: 390px;
    left: 825px;
  }

  #four {
    font-family: "Times New Roman", Times, serif;
      font-size:25px;
    position: absolute;
    bottom: 390px;
    left: 925px;
  }
  #errormessage1{
    font-family: "Times New Roman", Times, serif;
    font-size:15px;
    color:red;
    position: absolute;
    bottom: 480px;
    left: 505px;
  }
  #errormessage2{
    font-family: "Times New Roman", Times, serif;
    font-size:15px;
    color:red;
    position: absolute;
    bottom: 420px;
    left: 505px;
  }
  #errormessage3{
    font-family: "Times New Roman", Times, serif;
    font-size:15px;
    color:red;
    position: absolute;
    bottom: 370px;
    left: 505px;
  }
  #errormessage4{
    font-family: "Times New Roman", Times, serif;
    font-size:15px;
    color:red;
    position: absolute;
    bottom: 320px;
    left: 505px;
  }
  #errormessage5{
    font-family: "Times New Roman", Times, serif;
    font-size:15px;
    color:red;
    position: absolute;
    bottom: 270px;
    left: 505px;
  }
  #errormessage6{
    font-family: "Times New Roman", Times, serif;
    font-size:15px;
    color:red;
    position: absolute;
    bottom: 220px;
    left: 505px;
  }
  #red{
    font-family: "Times New Roman", Times, serif;
    font-size:15px;
    color:blue;
    position: absolute;
    top: 120px;
    left: 510px;
  }
</style>

<body>
  <div>

    <nav class="navbar navbar-expand-sm  navbar-light" id="style">

      <div class="container">
        <span class="brand-logo">Pick and Drop System</span>

        <ul class="navbar-nav right">

          <li id="col"><a href="sign2.php">Logout</a></li>

        </ul>
      </div>
    </nav>
<form method="post">
    <ul class="rights">
      <li class="id1"><button class="btn btn-outline-primary" name="next" id="btn2"><a href="rider.php">View Rides</a></button>
      </li>
      <li class="id1"><button class="btn btn-outline-primary" name="next" id="btn2"><a href="profile.php">View Profile</a></button>
      </li>
      <li class="id1"><button class="btn btn-outline-primary" name="next" id="btn2"><a href="role.php">Home</a></button></li>


    </ul>
</form>
    <?php
    if(isset($_POST['txtbutton']))
    {
        $my = new mysqli('localhost', 'root', '', 'aoa');
$array=array();

//$sql="SELECT driver.id, driver.username, driver.start,driver.destination,driver.seats,driver.vehicle,driver.fare,driver.time,signup.phone FROM driver RIGHT JOIN signup ON driver.username=signup.username";
$sql="SELECT * FROM driver";
$result = $my->query($sql);
if ($result->num_rows > 0) {
  $j=0;
 while($row = $result->fetch_assoc()) {
   // $records[$row['id']] = array('title'=>$row['title'], 'url'=>$row['url']);
   $j++;
   $d=$row["id"];
$driver=$row["username"];
 $start=$row["start"];
 $dest=$row["destination"];
 $seats=$row["seats"];
 $vehicle=$row["vehicle"];
 $fare=$row["fare"];
 $time=$row["time"];
 


 $array[$j][0]=$d;
 $array[$j][1]=$driver;
 $array[$j][2]=$start;
 $array[$j][3]=$dest;
 $array[$j][4]=$seats;
 
 $array[$j][5]=$time;
 $array[$j][6]=$fare;
 $array[$j][7]=$vehicle;
  
echo $j;
}
}
$_SESSION["array"]=$array;
for ($k=1;$k<=$j;$k++)
{
  
  for ($o=0;$o<=7;$o++)
  {
    
  echo $array[$k][$o];
  echo "\r\n";
  }
  
  echo "<br>\n";
}

}
    
    ?>
    <form method="post">
    <span id="red">*Enter Only Captial Letters!</span>
      <div class="form-group <?php echo (!empty($start_err)) ? 'has-error' : ''; ?>">
        <span id="Sec">Enter PickUp-Point:</span>
        <input type="text" id="pickUp" name="start" pattern="[A-Z]*" required onBlur="validName()"/>
        <span id="errormessage1" class="help-block"><?php echo $start_err; ?></span>
      </div>

      <div class="form-group <?php echo (!empty($dest_err)) ? 'has-error' : ''; ?>">
        <span id="Sec1">Enter Destination:</span>
        <input type="text" id="drop1" name="dest"  pattern="[A-Z]*" required onBlur="validdest()"/>
        <span id="errormessage2" class="help-block"><?php echo $dest_err; ?></span>
      </div>
      <div class="form-group <?php echo (!empty($seats_err)) ? 'has-error' : ''; ?>">
        <span id="Sec2">Enter Available Seats:</span>

        <input type="radio" id="drop2" name="seats" value="1"/>
        <span id="one">1</span>
        <input type="radio" id="drop3" name="seats" value="2"/>
        <span id="two">2</span>
        <input type="radio" id="drop4" name="seats"value="3"/>
        <span id="three">3</span>
        <input type="radio" id="drop5" name="seats" value="4"/>
        <span id="four">4</span>
        <span id="errormessage3" class="help-block"><?php echo $seats_err; ?></span>
      </div>
      
        
        <div class="form-group <?php echo (!empty($vehicle_err)) ? 'has-error' : ''; ?>">
          <span id="Sec3">Enter Vehicle Type:</span>
          <select id="drop6" name="vehicle" readonly>
            <option></option>
            <option>Motor Cycle</option>
            <option>Auto</option>
            <option>Car</option>
            <option>Car AC</option>
          </select>
          <span id="errormessage4" class="help-block"><?php echo $vehicle_err; ?></span>
          </div>
          <button class="btn btn-outline-danger" id="btnAdd" name="txtbutton">Add</button>
        
    

      <div  class="form-group <?php echo (!empty($fare_err)) ? 'has-error' : ''; ?>" >
        <span id="Sec4">Enter Fare:</span>
        <input type="number" min="0" id="drop7" name="fare"/>
        <span id="errormessage5" class="help-block"><?php echo $fare_err; ?></span>
      </div>

      <div class="form-group <?php echo (!empty($time_err)) ? 'has-error' : ''; ?>">
        <span id="Sec5">Enter Time:</span>
        <input type="time" id="drop8" name="time" />
        <span id="errormessage6" class="help-block"><?php echo $time_err; ?></span>
      </div>
    </form>





    <div id="logo"></div>
    <div id="logo1"></div>

  </div>
</body>

</html>