<?php session_start(); ?>
<?php
$id=$id_err=$ids=$ids_err="";
    if(isset($_POST['cancel'])){
      if(empty(trim($_POST["ID"]))){
        $id_err = "*Please enter an ID.";
    } else{
        $id= trim($_POST["ID"]);
    }
    if(empty($id_err)){
      $mysql = new mysqli('localhost', 'root', '', 'aoa');
      if($mysql->connect_error)
          {
          echo $mysql->connect_error;
          }
     
       
         $sect = $_POST["ID"];
         $sql="DELETE FROM driver WHERE id='$sect'";
         $mysql->query($sql);  
         if(!$mysql) 
            { echo mysql_error(); }
            
         header("location: profile.php");
        }
     }

     if(isset($_POST['can'])){
      if(empty(trim($_POST["IDT"]))){
        $ids_err = "*Please enter an ID!";
    } else{
        $ids= trim($_POST["IDT"]);
    }
    if(empty($ids_err)){
      $mysql = new mysqli('localhost', 'root', '', 'aoa');
      if($mysql->connect_error)
          {
          echo $mysql->connect_error;
          }
     
       
         $sect = $_POST["IDT"];
         $sql="DELETE FROM rides WHERE id='$sect'";
         $mysql->query($sql);  
         if(!$mysql) 
            { echo mysql_error(); }
            
         header("location: profile.php");
        }
     }
    ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://fonts.googleapis.com/css?family=Literata&display=swap" rel="stylesheet">
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <title>Profile </title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <!-- Bootstrap -->
  <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">-->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
    integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.4.1.js" integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
    crossorigin="anonymous"></script>
</head>

<style>
  #btn8 {
    font-family: "Times New Roman", Times, serif;
    position: absolute;
    bottom: 370px;
    left: 800px;
    font-size: 20px;

  }

  #style {
    font-family: "Times New Roman", Times, serif;
    height: 70px;
    background-color: darkblue;
  }

  .rights {
    list-style-type: none;
    margin: 0;
    padding: 0;
    width: 200px;
    height: 1500px;
    background-color: darkblue;
  }

  #btn2 {
    font-family: "Times New Roman", Times, serif;
    font-size: 20px;
    margin-left: 8px;
    margin-right: 20px;
    width: 180px;
    margin-top: 7px;
    border-radius: 10px;
    height: 50px;
    border: 1px solid darkblue;

  }

  Button a:hover {

    color: white;
  }

  #btnAdd {
    font-family: "Times New Roman", Times, serif;
    position: absolute;
    bottom: 220px;
    left: 700px;
    font-size: 20px;

  }

  #errormessage1 {
    font-family: "Times New Roman", Times, serif;
    font-size: 15px;
    color: red;
    position: absolute;
    left: 510px;
    bottom: 532px;
    display: relative;

  }

  #errormessage2 {
    font-family: "Times New Roman", Times, serif;
    font-size: 15px;
    color: red;
    position: absolute;
    left: 510px;
    bottom: 480px;
    display: relative;
  }

  #errormessage3 {
    font-family: "Times New Roman", Times, serif;
    font-size: 15px;
    color: red;
    position: absolute;
    left: 510px;
    bottom: 420px;
    display: relative;

  }


  table {
    border-collapse: collapse;
    width: 100%;
    color: darkblue;
    font-family: monospace;
    font-size: 25px;
    text-align: left;
  }

  th {
    background-color: darkblue;
    color: white;
  }

  tr:nth-child(even) {
    background-color: lightblue
  }

  #table1 {
    font-family: "Times New Roman", Times, serif;
    position: absolute;
    top: 300px;
    left: 260px;
    width: 1000px;
    border: 4px;

  }


  #table2 {
    font-family: "Times New Roman", Times, serif;
    position: absolute;
    top: 750px;
    /*bottom: 260px;*/
    left: 260px;
    width: 1000px;
    border: 4px;

  }

  #table3 {
    font-family: "Times New Roman", Times, serif;
    position: absolute;
    /*bottom: 120px;*/
    top: 1300px;
    left: 260px;
    width: 1000px;
    border: 4px;

  }


  #logo {
    background-image: url("./images/images.jpg");
    background-repeat: no-repeat;
    background-size: 65px;
    border: 1px solid blue;
    position: absolute;
    top: 10px;
    left: 19px;
    width: 67px;
    height: 50px;

  }

  #logo1 {
    background-image: url("./images/download1.jpg");
    background-repeat: no-repeat;
    background-size: 70px;
    border: 1px solid white;
    position: absolute;
    top: 70px;
    left: 1210px;
    width: 100px;
    height: 100px;

  }

  #btn2 {
    background-color: lightskyblue;
  }

  li a:hover {
    color: white;
  }

  .navbar-light {
    background-color: darkblue;
    color: white;
  }

  .brand-logo {
    font-size: 30px;
  }

  #col {
    margin-right: 10px;
    font-size: 20px;
  }


  #Sec {
    font-family: "Times New Roman", Times, serif;
    font-size: 25px;
    position: absolute;
    bottom: 550px;
    left: 300px;
  }

  #Sec1 {
    font-family: "Times New Roman", Times, serif;
    font-size: 25px;
    position: absolute;
    bottom: 500px;
    left: 300px;
  }

  #Sec2 {
    font-family: "Times New Roman", Times, serif;
    font-size: 30px;
    position: absolute;
    bottom: 460px;
    left: 600px;
  }

  #Sec3 {
    font-family: "Times New Roman", Times, serif;
    font-size: 30px;
    position: absolute;
    top: 650px;
    left: 600px;
  }

  #Sec4 {
    font-family: "Times New Roman", Times, serif;
    font-size: 30px;
    position: absolute;
    top: 1120px;
    left: 620px;
  }


  #name {

    font-family: "Times New Roman", Times, serif;
    position: absolute;
    bottom: 500px;
    left: 500px;
    width: 700px;
    height: 30px;

  }

  #drop1 {

font-family: "Times New Roman", Times, serif;
position: absolute;
bottom: 450px;
left: 500px;
width: 700px;
height: 30px;
}
#na{
  font-family: "Times New Roman", Times, serif;
  font-size:25px;
position: absolute;
bottom: 550px;
left: 400px;
}
#na1{
  font-family: "Times New Roman", Times, serif;
  font-size:25px;
position: absolute;
bottom: 500px;
left: 400px;
}
#sp2{
  font-family: "Times New Roman", Times, serif;
  font-size:25px;
position: absolute;
top: 1050px;
left: 300px;
}
#sp2t{
  font-family: "Times New Roman", Times, serif;
  font-size:25px;
position: absolute;
top: 1050px;
left: 400px;
}
#spb{
  font-family: "Times New Roman", Times, serif;
  font-size:25px;
position: absolute;
top: 1050px;
left: 750px;
}
#sp1{
  font-family: "Times New Roman", Times, serif;
  font-size:25px;
position: absolute;
top: 590px;
left: 300px;
}
#sp1t{
  font-family: "Times New Roman", Times, serif;
  font-size:25px;
position: absolute;
top: 590px;
left: 400px;
}
#sp1b{
  font-family: "Times New Roman", Times, serif;
  font-size:25px;
position: absolute;
top: 590px;
left: 750px;
}
#errormessage4{
    font-family: "Times New Roman", Times, serif;
    font-size: 15px;
    color: red;
    position:absolute;
    left:410px;
    bottom:25px;
    display:relative;
    
  }
  #errormessage5{
    font-family: "Times New Roman", Times, serif;
    font-size: 15px;
    color: red;
    position:absolute;
    left:400px;
    top:1100px;
    display:relative;
    
  }
</style>

<body>
  <div>

    <nav class="navbar navbar-expand-sm  navbar-light" id="style">

      <div class="container">
        <span class="brand-logo">Pick and Drop System</span>

        <ul class="navbar-nav right">

          <li id="col"><a href="sign2.php">Logout</a></li>

        </ul>
      </div>
    </nav>

    <ul class="rights">
      <li class="id1"><button class="btn btn-outline-primary" id="btn2"><a href="rider.php">View Rides</a></button>
      </li>
      <li class="id1"><button class="btn btn-outline-primary" id="btn2"><a href="profile.php">View Profile</a></button>
      </li>
      <li class="id1"><button class="btn btn-outline-primary" id="btn2"><a href="role.php">Home</a></button></li>


    </ul>
    <form method="post">
      <div>
        <span id="Sec"><b> Name:</b></span>
        <?php 
        $username=$_SESSION["username"];
        echo "<span id='na'>$username</span>";
        ?>
        
      </div>

      <div>
        <span id="Sec1"><b>Phone:</b></span>
        <?php 
        $phone=$_SESSION["phone"];
        echo "<span id='na1'>$phone</span>";
        ?>
      </div>
      <div>
              <span id="Sec2"><b><u>Rides Provided By You</u></b></span>
              
              <span id="Sec3"><b><u>Rides Booked By You</u></b></span>
              <span id="Sec4"><b><u>Your Customers</u></b></span>

    <table id="table1">
            <tr>
            <th>#</th>
            <th>ID</th>
            <th>Pick-Up</th>
            <th> Destination</th>
            <th>Time</th>
            <th> Fare</th>
            <th>Seats</th>
            </tr>
            <?php


 
/* Attempt to connect to MySQL database */
$link = new mysqli('localhost', 'root', '', 'aoa');
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

  
  $username =$_SESSION["username"];
  $id =$_SESSION["id"];
  
  $sql = "SELECT * FROM driver WHERE username='$username' ";
  $result = $link->query($sql);
  if ($result->num_rows > 0) {
  $i=0;
    // output data of each row
    while($row = $result->fetch_assoc()) {
    $i++;
    echo "<tr><td>" . $i. "</td><td>" .$row["id"] . "</td>
    <td>" . $row["start"] . "</td><td>" . $row["destination"] . "</td><td>" . $row["fare"] . "</td><td>" . $row["time"] . "</td><td>" . $row["seats"] . "</td></tr>";
    }
  }
  else { echo "0 results"; }
$link->close();


?>
     </table>

     <table id="table2">
            <tr>
            <th>#</th>
            <th>ID</th>
            <th> Driver</th>
            <th> Phone</th>
            <th> Pick-Up</th>
            <th>Destination</th>
            <th>Fare</th>
            <th>Seats</th>
            <th>Time</th>
            </tr>
<?php


/* Attempt to connect to MySQL database */
$li = new mysqli('localhost', 'root', '', 'aoa');
// Check connection
if($li === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
  $id =$_SESSION["id"];
  //$sql = "SELECT driver.id, driver.username, driver.start,driver.destination,driver.seats,driver.vehicle,driver.fare,driver.time,signup.phone FROM driver RIGHT JOIN signup ON driver.username=signup.username WHERE driver.id='$id'";
  $sql="SELECT * FROM rides WHERE usersid=$id";
  $result = $li->query($sql);
  if ($result->num_rows > 0) {
  $i=0;
    // output data of each row
    while($row = $result->fetch_assoc()) {
    $i++;
    echo "<tr><td>" . $i. "</td><td>" . $row["id"] . "</td><td>" . $row["drivername"] . "</td><td>" . $row["phone"] . "</td><td>" . $row["start"] . "</td><td>" . $row["destination"] . "</td>
    <td>" . $row["fare"] . "</td><td>" . $row["seats"] . "</td><td>" . $row["time"] . "</td></tr>";
    }
  }
  else { echo "0 results"; }
$li->close();


?>
     </table>

     <table id="table3">
            <tr>
            <th>#</th>
            <th>Rider-Name</th>
            <th>Phone No</th>
            <th>Pick-Up</th>
            <th>Destination</th>
            <th>Time</th>
            <th>Seats Available</th>
            <th>Fare</th>

            
            </tr>
 <?php


/* Attempt to connect to MySQL database */
$mysql = new mysqli('localhost', 'root', '', 'aoa');
// Check connection
if($mysql === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

  $username =$_SESSION["username"];
  $id =$_SESSION["id"];
  $sql = "SELECT * FROM rides WHERE drivername='$username'";
  $result = $mysql->query($sql);
  if ($result->num_rows > 0) {
  $i=0;
    // output data of each row
    while($row = $result->fetch_assoc()) {
    $i++;
    echo "<tr><td>" . $i. "</td><td>" . $row["username"] . "</td><td>" . $row["phone"] . "</td><td>" . $row["start"] . "</td><td>" . $row["destination"] . "</td>
    <td>" . $row["time"] . "</td><td>" . $row["seats"] . "</td><td>" . $row["fare"] . "</td></tr>";
    }
  }
  else { echo "0 results"; }
$mysql->close();


?> 
     </table>




    <div id="logo"></div>
    <div id="logo1"></div>


    <form method="post">
      <div class="form-group <?php echo (!empty($id_err)) ? 'has-error' : ''; ?>">
      <span id="sp1">Enter ID:</span>
      <input type="number" min="0" id="sp1t" name="ID"/>
      <span id="errormessage4" class="help-block"><?php echo $id_err; ?></span>
      </div>
      <button name="cancel" id="sp1b">Cancel</button>
      <div class="form-group <?php echo (!empty($ids_err)) ? 'has-error' : ''; ?>">
      <span id="sp2">Enter ID:</span>
      <input type="number" min="0"  id="sp2t" name="IDT"/>
      <span id="errormessage5" class="help-block"><?php echo $ids_err; ?></span>
      </div>
      <button name="can" id="spb">Cancel</button>
    </form>
    
  </div>
</form>    
</body>

</html>