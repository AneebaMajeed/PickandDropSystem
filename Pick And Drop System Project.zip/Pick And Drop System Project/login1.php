<?php
/* Database credentials. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'aoa');
 
/* Attempt to connect to MySQL database */
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
$email=$email_err=$password=$password_err="";
if(isset($_POST['txtbutton'])){
if(empty(trim($_POST["email"]))){
    $email_err  = "*Please enter email!";
    
    } else{
        $email = trim($_POST["email"]);
    }
    // Check if password is empty
    if(empty(trim($_POST["password"]))){
        $password_err = "*Please enter your password!";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate credentials
    if(empty($username_err) && empty($password_err)){
        // Prepare a select statement
        $sql = "SELECT id, username, password,phone,email FROM signup WHERE email = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_email);
            
            // Set parameters
            $param_email = $email;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Store result
                mysqli_stmt_store_result($stmt);
                
                // Check if username exists, if yes then verify password
                if(mysqli_stmt_num_rows($stmt) == 1){                    
                    // Bind result variables
                    mysqli_stmt_bind_result($stmt, $id, $username, $hashed_password,$phone,$email);
                    if(mysqli_stmt_fetch($stmt)){
                        if(password_verify($password, $hashed_password)){
                            // Password is correct, so start a new session
                            session_start();
                            
                            // Store data in session variables
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["phone"] = $phone;
                            $_SESSION["username"] = $username;
                            $_SESSION["email"] = $u;                            
                            
                            // Redirect user to welcome page
                            header("location: role.php");
                        } else{
                            // Display an error message if password is not valid
                            $password_err = "*The password you entered was not valid!";
                        }
                    }
                } else{
                    // Display an error message if username doesn't exist
                    $email_err = "*No account found with that email!";
                }
            }
        } 
    } 
} 

?>
<html>
<head>
<title>Login</title>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<style>
    #btnn
  {
    width:120px;
    margin-left:150px;
    margin-top:10px;
    display: flex;
    align-items: center;
    flex-direction:column;
    text:white;
  }
 
.wrapper{
    height:100vh;
    width:100%;
    justify-content:center;
    background-color: darkcyan;
    /*background-image:url("./images/pic8.jpg");*/
    background-repeat:no-repeat;
    background-size:100%;
    align-items: center;
    display:flex;
    flex-direction:column;
  
  }
  .form-wrapper{
    width:500px;
    height:600px;
    display:flex;
    flex-direction:column;
    padding: 20px 40px;
    border-radius: 10px;
    box-shadow: 0px 10px 50px #555;
    background-color: aliceblue;
    border:4px blue solid;
  
  }
 
  form{
    
    width:100%;
  }
  input::placeholder{
    font-family: "Times New Roman", Times, serif;
  }
  h1{
  
  text-align: center;
  width:100%;
  color:blue;
  font-family: "Times New Roman", Times, serif;
}
label{
    font-family: "Times New Roman", Times, serif;
    font-size: 17px;
    font-weight:lighter;
    margin-top:30px;
    margin-bottom: 5px;
    color: #222;
  }
  
  input{
    font-family: "Times New Roman", Times, serif;
    padding: 20px 200px 10px 10px;
    margin-bottom: 5px;
    margin-right: 10px;
    border-radius: 5px;
    outline:none;
     
  }
  
  Button a:hover {
  
  color:white;
}
#errormessage{
  font-family: "Times New Roman", Times, serif;
  font-size:15px;
  color:red;
}
#btnn2{
    width:120px;
    margin-left:150px;
    margin-top:10px;
    display: flex;
    align-items: center;
    flex-direction:column;
    text:white;
}
  </style>




  <body>
<div class="wrapper">
       <div class="form-wrapper">
         <h1>Login To Account</h1>
       <form method="post" >
          <div  class="form-group <?php echo (!empty($email_err)) ? 'has-error' : ''; ?>">
          <label htmlFor="email">Email:</label>
          <input type="text" placeholder="Email" id="email"  name="email" />
          <span id="errormessage" class="help-block"><?php echo $email_err; ?></span>
          </div>

          <div class="form-group <?php echo (!empty($password_err)) ? 'has-error' : ''; ?>">
          <label htmlFor="password">Password:</label>
          <input type="password" placeholder="Password" id="password" name="password" />
          <span id="errormessage" class="help-block"><?php echo $password_err; ?></span>
          </div>
         
          <div class="submit">
          <button type="submit" name="txtbutton" class="btn btn-outline-primary" id="btnn"  >Login</button>
          </div>

         </form>
         <button type="submit"  class="btn btn-primary" id="btnn2"  >Back</button>
       </div>  
    </div>
    </body>
    </html>
  