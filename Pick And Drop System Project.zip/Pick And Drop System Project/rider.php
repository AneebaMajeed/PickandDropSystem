<?php session_start();
$start=$start_err=$dest=$dest_err=$seats=$seats_err=$time=$time_err="";
if(isset($_POST['txtbutton']))
{

    if(empty(trim($_POST["start"]))){
        $start_err = "*Please enter a Pickup point.";
    } else{
        $start= trim($_POST["start"]);
    }
    if(empty(trim($_POST["dest"]))){
        $dest_err = "*Please enter a destination.";
    } else{
        $dest = trim($_POST["dest"]);
    }
    if (!isset($_POST['seats'])){
        $seats_err = "*Please enter Seats.";
  
    } else{
        $seats = trim($_POST["seats"]);
    }
    if(empty(trim($_POST["time"]))){
        $time_err = "*Please enter a time.";
    } else{
        //$time = trim($_POST["time"]);
        $time = date('h:i:s a', strtotime($_POST['time']));
    }
 }
 $id=$id_err="";
 if(isset($_POST['txtbut'])){
    if(empty(trim($_POST["sect"]))){
        $id_err = "*Please enter an ID!";
    } else{
        $id= trim($_POST["sect"]);
    } 
 }
 ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
     <link href="https://fonts.googleapis.com/css?family=Literata&display=swap" rel="stylesheet">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>btmZZzz Form</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <!-- Bootstrap -->
   <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">-->
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
     <script
        src="https://code.jquery.com/jquery-3.4.1.js"
        integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
        crossorigin="anonymous"></script> 
    </head>
    <script>
        /*  function validName(){
            var n=document.getElementById("date").value;
            var flag=false;
          
            for(let i=0;i<n.length;i++)
            {
                var nm=n.charCodeAt(i);
            if(!(((nm>64 && nm<91) || (nm>94 && nm<123)) || (nm==32)))
            {
                 flag=true; 
            }
            
            }
            if(flag==true){
               
              var h=document.getElementById("errormessage1");
            
             h.innerHTML="Invalid Input!! Enter only letters!";
              
              document.getElementById("date").focus();
              

            }
            else
            {
                 var h=document.getElementById("errormessage1");
                
                 h.innerHTML="";
            }

        } 
        function validdest(){
            var n=document.getElementById("drop6").value;
            var flag=false;
          
            for(let i=0;i<n.length;i++)
            {
                var nm=n.charCodeAt(i);
            if(!(((nm>64 && nm<91) || (nm>94 && nm<123)) || (nm==32)))
            {
                 flag=true; 
            }
            
            }
            if(flag==true){
               
              var h=document.getElementById("errormessage2");
              
             h.innerHTML="Invalid Input!! Enter only letters!";
              
              document.getElementById("drop6").focus();
              

            }
            else
            {
                 var h=document.getElementById("errormessage2");
                
                 h.innerHTML="";
            }

        } */
    </script>
 
 <style>
     
     #btn8
   {
    font-family: "Times New Roman", Times, serif;
    position:absolute;
    bottom:370px;
    left:800px;
    font-size: 20px;
     
   }
   #style{
    font-family: "Times New Roman", Times, serif;
    height:70px;
    background-color:darkblue;
   }   
   .rights{
    list-style-type: none;
    margin: 0;
    padding: 0;
    width: 200px;
    height:670px;
    background-color:darkblue;
   }
   
   #btn2
   {
    font-family: "Times New Roman", Times, serif;
    font-size: 20px;
     margin-left:8px;
     margin-right:20px;
     width:180px;
     margin-top:7px;
     border-radius:10px; 
     height:50px;
     border:1px solid darkblue;
     
   }
   
   Button a:hover {
  
    color:white;
  }
  #btn7
   {
    font-family: "Times New Roman", Times, serif;
    position:absolute;
    bottom:330px;
    left:700px;
    font-size: 20px;
     
   }
   #errormessage1{
    font-family: "Times New Roman", Times, serif;
    font-size: 15px;
    color: red;
    position:absolute;
    left:510px;
    bottom:532px;
    display:relative;
    
  }
  #errormessage2{
    font-family: "Times New Roman", Times, serif;
    font-size: 15px;
    color: red;
    position:absolute;
    left:510px;
    bottom:480px;
    display:relative;
  }
  #errormessage3{
    font-family: "Times New Roman", Times, serif;
    font-size: 15px;
    color: red;
    position:absolute;
    left:510px;
    bottom:420px;
    display:relative;
    
  }
  #errormessage4{
    font-family: "Times New Roman", Times, serif;
    font-size: 15px;
    color: red;
    position:absolute;
    left:510px;
    bottom:370px;
    display:relative;
    
  }
  #errormessage5{
    font-family: "Times New Roman", Times, serif;
    font-size: 15px;
    color: red;
    position:absolute;
    left:400px;
    top:610px;
    display:relative;
    
  }

 
  
table {
border-collapse: collapse;
width: 100%;
color: darkblue;
font-family: monospace;
font-size: 25px;
text-align: left;
}
th {
background-color: darkblue;
color: white;
}
tr:nth-child(even) {background-color: lightblue}
  
  #table
  {
    font-family: "Times New Roman", Times, serif;
    position:absolute;
    bottom:100px;
    left:260px;
    width:1000px;
    border:4px;
    
  }


  #logo
{
  background-image:url("./images/images.jpg");
    background-repeat:no-repeat;
    background-size:65px;
    border:1px solid blue;
    position:absolute;
    top:10px;
    left:19px;
    width:67px;
    height:50px;

}

#logo1
{
  background-image:url("./images/download1.jpg");
    background-repeat:no-repeat;
    background-size:70px;
    border:1px solid white;
    position:absolute;
    top:70px;
    left:1210px;
    width:100px;
    height:100px;

}
#btn2{
  background-color: lightskyblue;
}
li a:hover{
  color:white;
}
.navbar-light{
    background-color:darkblue;
    color:white;
}
.brand-logo{
    font-size:30px;
}
#col{
    margin-right:10px;
    font-size: 20px;
}

  #Sec1
   {
    font-family: "Times New Roman", Times, serif;
    font-size: 25px;
    position:absolute;
    bottom:440px;
    left:300px;
   }   
  #drop2{

  font-family: "Times New Roman", Times, serif;
  position:absolute;
  bottom:445px;
  left:500px;
  width: 700px;
  height:30px;
   }
  #drop6{

font-family: "Times New Roman", Times, serif;
position:absolute;
bottom:506px;
left:500px;
width: 700px;
height:30px;
 }
  #Sec
   {
    font-family: "Times New Roman", Times, serif;
    font-size: 25px;
    position:absolute;
    bottom:500px;
    left:300px;
   } 
   #Sec2
   {
    font-family: "Times New Roman", Times, serif;
    font-size: 25px;
    position:absolute;
    bottom:390px;
    left:300px;
   }   
   #Sec3
   {
    font-family: "Times New Roman", Times, serif;
    font-size: 25px;
    position:absolute;
    bottom:550px;
    left:300px;
   }
   #date{

font-family: "Times New Roman", Times, serif;
position:absolute;
bottom:550px;
left:500px;
width:700px;
height:30px;

 }
 #drop1{
position:absolute;

bottom:450px;
left:600px;
 }
 #drop7{
position:absolute;

bottom:450px;
left:700px;
 }
 #drop3{
position:absolute;

bottom:450px;
left:800px;
 }
 #drop4{
position:absolute;

bottom:450px;
left:900px;
 }
 #drop5{
position:absolute;
font-family: "Times New Roman", Times, serif;
bottom:390px;
left:500px;
width: 700px;
height:30px;
 }
 #one{
    font-family: "Times New Roman", Times, serif;
      font-size:25px;
position:absolute;
bottom:440px;
left:625px;
 }
 #two{
    font-family: "Times New Roman", Times, serif;
      font-size:25px;
position:absolute;
bottom:440px;
left:725px;
 }
 #three{
    font-family: "Times New Roman", Times, serif;
      font-size:25px;
position:absolute;
bottom:440px;
left:825px;
 }
 #four{
    font-family: "Times New Roman", Times, serif;
      font-size:25px;
position:absolute;
bottom:440px;
left:925px;
 }
 #rr1{
    font-family: "Times New Roman", Times, serif;
    font-size: 25px;
    position:absolute;
    bottom:5px;
    left:260px;
  }
  #rr2{
    font-family: "Times New Roman", Times, serif;
    font-size: 25px;
    position:absolute;
    bottom:5px;
    left:400px;
    height:40px;
  }
  #rr3{
    font-family: "Times New Roman", Times, serif;
    font-size: 20px;
    position:absolute;
    bottom:5px;
    left:750px;
    height:40px;
    padding:5px;
    margin-top:5px;
  }
  #alert{
    font-family: "Times New Roman", Times, serif;
    font-size: 20px;
    position:absolute;
    top:360px;
    left:550px;
    width:450px;
  }
  #red{
    font-family: "Times New Roman", Times, serif;
    font-size:15px;
    color:blue;
    position: absolute;
    top: 80px;
    left: 510px;
  }
</style>

  <body>
  <div>
  
        <nav class="navbar navbar-expand-sm  navbar-light" id="style">
            
            <div class="container">
            <span class="brand-logo">Pick and Drop System</span>
            
                <ul class="navbar-nav right">
                    
                    <li id="col"><a href="sign2.php">Logout</a></li>
                    
                </ul>
            </div>
            </nav>
            
            <ul class="rights" >
                <li class="id1"><button class="btn btn-outline-primary" id="btn2"><a href="rider.php">View Rides</a></button></li>
                <li class="id1"><button class="btn btn-outline-primary" id="btn2"><a href="profile.php">View Profile</a></button></li>
                <li class="id1"><button class="btn btn-outline-primary" id="btn2"><a href="role.php">Home</a></button></li>
              
                
            </ul>
<form method="post"> 
<span id="red">*Enter Only Captial Letters!</span>
    <div class="form-group <?php echo (!empty($start_err)) ? 'has-error' : ''; ?>"> 
    <span id="Sec3">Select Start-Point:</span>
    <input type="text" id="date" name="start" pattern="[A-Z]*" required onBlur="validName()"/> 
    <span id="errormessage1" class="help-block"><?php echo $start_err; ?></span>
    <span id="hh"></span>
    </div>
      
    <div class="form-group <?php echo (!empty($dest_err)) ? 'has-error' : ''; ?>">
    <span id="Sec">Select Destination:</span>
    <input type="text" id="drop6" name="dest" pattern="[A-Z]*" required onBlur="validdest()"/> 
    <span id="errormessage2" class="help-block"><?php echo $dest_err; ?></span>
    <span id="hh"></span>
    </div>

    <div class="form-group <?php echo (!empty($seats_err)) ? 'has-error' : ''; ?>">
    <span id="Sec1">Select Required Seats:</span>
    <input type="radio" id="drop1"  name="seats" value="1"/> 
    <span id="one">1</span>
    <input type="radio" id="drop7"  name="seats" value="2"/> 
    <span id="two">2</span>
    <input type="radio" id="drop3"  name="seats" value="3"/> 
    <span id="three">3</span>
    <input type="radio" id="drop4"  name="seats" value="4"/> 
    <span id="four">4</span>
    <span id="errormessage3" class="help-block"><?php echo $seats_err; ?></span>
    </div>
    
    <div class="form-group <?php echo (!empty($time_err)) ? 'has-error' : ''; ?>">
    <span id="Sec2">Enter Time:</span>
    <input type="time" id="drop5" name="time"/> 
    <span id="errormessage4" class="help-block"><?php echo $time_err; ?></span>
    </div> 

    <button class="btn btn-outline-danger" id="btn7" name="txtbutton" >Search</button>
      
</form>





<div id="logo"></div>
<div id="logo1"></div>

<table id="table">
<tr>
<th>#</th>
<th>ID</th>
<th>Driver Name</th>
<th>Phone No</th>
<th>Fare</th>
<th>Seats Available</th>
<th>Time</th>
</tr>
<?php

define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'aoa');
 
/* Attempt to connect to MySQL database */
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
//$start=$start_err=$dest=$dest_err=$seats=$seats_err=$time=$time_err="";
if(isset($_POST['txtbutton']))
{

    if(empty($start_err) && empty($dest_err) && empty($seats_err) && empty($time_err)){
  $start=$_POST["start"];
  $dest=$_POST["dest"];
  $seats=$_POST["seats"];
  $_SESSION["seats"]=$seats;
 // $time=$_POST["time"];
 $time = date('h:i:s a', strtotime($_POST['time']));
  $username =$_SESSION["username"];

 
  $x=array(array($start,$dest,$time,$seats));
  $sql = "SELECT driver.id, driver.username, driver.start,driver.destination,driver.seats,driver.vehicle,driver.fare,driver.time,signup.phone FROM driver RIGHT JOIN signup ON driver.username=signup.username WHERE start='$start' AND destination='$dest' AND time='$time' AND seats >= '$seats' ";
  $result = $link->query($sql);
  if ($result->num_rows > 0) {
  $i=0;
    // output data of each row
    while($row = $result->fetch_assoc()) {
    $i++;
    echo "<tr><td>" . $i. "</td><td>" . $row["id"]. "</td><td>" . $row["username"] . "</td><td>" . $row["phone"] . "</td>
    <td>" . $row["fare"] . "</td><td>" . $row["seats"] . "</td><td>" . $row["time"] . "</td></tr>";
    }
  }
  
$link->close();
 // by arrays 
 //$array=$_SESSION["array"];

 $my = new mysqli('localhost', 'root', '', 'aoa');
 $array=array();
 
 //$sql="SELECT driver.id, driver.username, driver.start,driver.destination,driver.seats,driver.vehicle,driver.fare,driver.time,signup.phone FROM driver RIGHT JOIN signup ON driver.username=signup.username";
 $sql="SELECT * FROM driver";
 $result = $my->query($sql);
 if ($result->num_rows > 0) {
   $j=0;
  while($row = $result->fetch_assoc()) {
    // $records[$row['id']] = array('title'=>$row['title'], 'url'=>$row['url']);
    $j++;
    $d=$row["id"];
 $driver=$row["username"];
  $start=$row["start"];
  $dest=$row["destination"];
  $seats=$row["seats"];
  $vehicle=$row["vehicle"];
  $fare=$row["fare"];
  $time=$row["time"];
  //$time = date('h:i:s a', strtotime($_POST['time']));
  
 
 
  $array[$j][0]=$d;
  $array[$j][1]=$driver;
  $array[$j][2]=$start;
  $array[$j][3]=$dest;
  $array[$j][4]=$time;
  
  $array[$j][5]=$seats;
  $array[$j][6]=$fare;
  $array[$j][7]=$vehicle;
   
 
 }
 
 }
 
 


 $front = 1;
 $back = count($array); 
 
 while ($front <= $back) 
 { 
   $l = 0;
   $loop=0;
   $u=0;
   for ($j=2;$j<5;$j++)
   {

         if ($array[$front][$j] == $x[0][$u] || $array[$back][$j] == $x[0][$u] ) 
         {
             if($array[$front][$j] == $x[0][$u])
             {
                 $loop=$front;
             }
             if($array[$back][$j] == $x[0][$u])
             {
                 $loop=$back;
             }
             $l++;
             
 
         
         }
       
        $u++;
         }
            
         
            if($array[$back][2] ==$x[0][0] && $array[$back][3] == $x[0][1] && $array[$back][4] ==$x[0][2]){
              
                if($array[$back][5] >=$x[0][3])
                {
                    $l++;
                  
                }
            }
            if($array[$front][2] ==$x[0][0] && $array[$front][3] == $x[0][1] && $array[$front][4] ==$x[0][2]){
             
                if($array[$front][5] >=$x[0][3])
                {
                    $l++;
                    
                }
            }
          
           
   
   
   if( $l==4)
   {
    echo "<div id='alert' class='alert alert-success alert-dismissible fade show'>
    <strong>Success!</strong> Your ride is available!
    </div>";
     goto end;
          
     }
    
     
  
   $front++; 
   $back--;
 }
end:
 if($l != 4)
 {
    echo "<div id='alert' class='alert alert-success alert-dismissible fade show'>
    <strong>Success!</strong> Your ride is not available!
    </div>";
 }
}

}
?>
</table>
<form method="post">
    <div  class="form-group <?php echo (!empty($id_err)) ? 'has-error' : ''; ?>">

    <label id="rr1">Enter ID:</label> 
    <input id="rr2" type="number" min="0" name="sect"/>
    <span id="errormessage5" class="help-block"><?php echo $id_err; ?></span>
    </div>
<button class="btn btn-outline-danger"  id="rr3" name="txtbut" >BooK</button>
<form>
<?php  
$mysql = new mysqli('localhost', 'root', '', 'aoa');

if($mysql->connect_error)
    {
    echo $mysql->connect_error;
    }


 if(isset($_POST['txtbut'])){
     if(empty($id_err)){
   $sect = $_POST["sect"];
   echo $sect;
   $id=$_SESSION["id"];
   $username=$_SESSION["username"];
   //$sql=" SELECT * FROM driver WHERE id='$sect'";
   $sql="SELECT driver.id, driver.username, driver.start,driver.destination,driver.seats,driver.vehicle,driver.fare,driver.time,signup.phone FROM driver RIGHT JOIN signup ON driver.username=signup.username WHERE  driver.id='$sect'";
   $result = $mysql->query($sql);
   if ($result->num_rows == 1) {
    while($row = $result->fetch_assoc()) {
    $my = new mysqli('localhost', 'root', '', 'aoa');
    $driver=$row["username"];
    $phone=$row["phone"];
    $start=$row["start"];
    $dest=$row["destination"];
    $seats=$row["seats"];
    $vehicle=$row["vehicle"];
    $fare=$row["fare"];
    //$time=$row["time"];
    $time = date('h:i:s a', strtotime($_POST['time']));
   
    $sq="INSERT INTO rides(usersid,username,drivername,phone,start,destination,seats,vehicle,fare,time) VALUES('$id','$username', '$driver','$phone','$start','$dest','$seats','$vehicle','$fare','$time')";
    $my->query($sq);
    //$my>query("INSERT INTO rides(usersid,username,drivername,phone,start,destination,seats,vehicle,fare,time) VALUES('$id','$username', '$driver','$phone','$start','$dest','$seats','$vehicle','$fare','$time')");
   
    if(!$my) 
    { echo mysqli_error(); }
    $mysql = new mysqli('localhost', 'root', '', 'aoa');
    $sql="SELECT * FROM driver WHERE id='$sect'";
   $result = $mysql->query($sql);
   if ($result->num_rows == 1) {
    while($row = $result->fetch_assoc()) {
$avail=$row["seats"];
echo $avail;

$seats=$_SESSION["seats"];
echo $seats;
    if($seats==$avail){
    $mysq = new mysqli('localhost', 'root', '', 'aoa');  
    $s="DELETE FROM driver WHERE id='$sect'";
    $mysq->query($s);
    }
    else if($seats<$avail)
    { 
        
        $new=$avail-$seats;
        $m = new mysqli('localhost', 'root', '', 'aoa');  
        $s="UPDATE driver SET seats='$new' WHERE id='$sect'";
        $m->query($s);
    }
}
   }
}
   }
else{ echo "0 results";}
     }
 } ?>
</div>
  </body>
  </html>