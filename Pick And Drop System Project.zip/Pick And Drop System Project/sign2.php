
<?php
/* Database credentials. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'aoa');
 
/* Attempt to connect to MySQL database */
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
$username=$username_err=$password=$password_err=$email=$email_err=$phone=$phone_err=$confirm_password=$confirm_password_err="";
if(isset($_POST['txtbutton']))
    {
       // Validate username
    if(empty(trim($_POST["username"]))){
        $username_err = "*Please enter a username.";
    } else{
        $username = trim($_POST["username"]);
    }
    
    // Validate password
    if(empty(trim($_POST["password"]))){
        $password_err = "*Please enter a password.";     
    } elseif(strlen(trim($_POST["password"])) < 6){
        $password_err = "*Password must have atleast 6 characters.";
    } else{
        $password = trim($_POST["password"]);
    }
    // Validate phone
    if(empty(trim($_POST["phone"]))){
        $phone_err = "*Please enter a Phone no!";     
    } elseif(strlen(trim($_POST["phone"])) != 10){
        $phone_err = "*Phone must have atleast 12 characters.";
    } else{
        $sql = "SELECT id FROM signup WHERE phone = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_phone);
            
            // Set parameters
            $param_phone = trim($_POST["phone"]);
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                /* store result */
                mysqli_stmt_store_result($stmt);
                
                if(mysqli_stmt_num_rows($stmt) >= 1){
                    $phone_err = "*This phone is already taken.";
                } else{
                    $phone = trim($_POST["phone"]);
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }
         
        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Validate confirm password
    if(empty(trim($_POST["confirm_password"]))){
        $confirm_password_err = "*Please confirm password.";     
    } else{
        $confirm_password = trim($_POST["confirm_password"]);
        if(empty($password_err) && ($password != $confirm_password)){
            $confirm_password_err = "*Password did not match.";
        }
    }

    // Validate Email
    if(empty(trim($_POST["email"]))){
        $email_err = "*Please enter an email.";     
    } else{
        $email=$_POST["email"];
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $email_err="*Invalid email Address";
        }
        else{
        $sql = "SELECT id FROM signup WHERE email = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_email);
            
            // Set parameters
            $param_email = trim($_POST["email"]);
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                /* store result */
                mysqli_stmt_store_result($stmt);
                
                if(mysqli_stmt_num_rows($stmt) >= 1){
                    $email_err = "*This email is already taken.";
                } else{
                    $email = trim($_POST["email"]);
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }
         
        // Close statement
        mysqli_stmt_close($stmt);
        
        
    } 
    if(empty($username_err) && empty($password_err) && empty($confirm_password_err) && empty($email_err) && empty($phone_err)){
        $param_password = password_hash($password, PASSWORD_DEFAULT); 
        $link->query("insert into signup(username,password,phone,email) values('$username', '$param_password','+92$phone','$email')");
    if(!$link) 
    { echo mysqli_error(); }
    else
    {
    header("location: login1.php");
    
    }
        
}
    }
    } 

?>
<html>
<script>
function validName(){
            var n=document.getElementById("username").value;
            var flag=false;
          
            for(let i=0;i<n.length;i++)
            {
                var nm=n.charCodeAt(i);
            if(!(((nm>64 && nm<91) || (nm>94 && nm<123)) || (nm==32)))
            {
                 flag=true; 
            }
            
            }
            if(flag==true){
               
              var h=document.getElementById("errormessage1");
            
             h.innerHTML="Invalid Input!! Enter only letters!";
              
              document.getElementById("username").focus();
              

            }
            else
            {
                 var h=document.getElementById("errormessage1");
                
                 h.innerHTML="";
            }

        } 
        function validPhone(){
            var n=document.getElementById("phone").value;
            var flag=false;
          
            for(let i=0;i<n.length;i++)
            {
                var nm=n.charCodeAt(i);
            if(!(nm>29 && nm<40))
            {
                 flag=true; 
            }
            
            }
            if(flag==true){
               
              var h=document.getElementById("errormessage2");
            
             h.innerHTML="Invalid Input!! Enter only Digits!";
              
              document.getElementById("phone").focus();
              

            }
            else
            {
                 var h=document.getElementById("errormessage2");
                
                 h.innerHTML="";
            }

        } 
</script>
<head>
<title>Sign Up</title>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" type="text/css" href="style.css">
    <!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">-->
    <link href="//cdn.muicss.com/mui-0.10.0/css/mui.min.css" rel="stylesheet" type="text/css" />
    <script src="//cdn.muicss.com/mui-0.10.0/js/mui.min.js"></script>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<style>
    #btnn
  {
    width:120px;
    margin-left:150px;
    margin-top:4px;
    display: flex;
    align-items: center;
    flex-direction:column;
  }
.wrapper{
    height:100vh;
    width:100%;
    justify-content:center;
    background-color: darkcyan;
    /*background-image:url("./images/pic8.jpg");*/
    background-repeat:no-repeat;
    background-size:100%;
    align-items: center;
    display:flex;
    flex-direction:column;
  
  }
  .form-wrapper{
    width:500px;
    height:700px;
    display:flex;
    flex-direction:column;
    padding: 20px 30px;
    border-radius: 10px;
    box-shadow: 0px 10px 50px #555;
    background-color: aliceblue;
    border:4px blue solid;
  
  }
  Button a:hover {
  
  color:white;
}
  form{
    
    width:100%;
  }
  input::placeholder{
    font-family: "Times New Roman", Times, serif;
  }
  h1{
  
    text-align: center;
    width:100%;
    color:blue;
    font-family: "Times New Roman", Times, serif;
    
  }
  
  label{
    font-family: "Times New Roman", Times, serif;
    font-size: 17px;
    font-weight:lighter;
    margin-top:0px;
    margin-bottom: 1px;
    color: #222;
  }
  #head{
    font-family: "Times New Roman", Times, serif;
  }
  input{
    font-family: "Times New Roman", Times, serif;
    padding: 5px 230px 5px 5px;
    margin-bottom: 2px;
    margin-right: 10px;
    border-radius: 5px;
    outline:none;
     
  }
 #errormessage{
    font-family: "Times New Roman", Times, serif;
    font-size:15px;
    color:red;

 }
 #errormessage1{
    font-family: "Times New Roman", Times, serif;
    font-size:15px;
    color:red;

 }
 #errormessage2{
    font-family: "Times New Roman", Times, serif;
    font-size:15px;
    color:red;

 }
  p{
    font-family: "Times New Roman", Times, serif;
    margin-left:90px;
  }
  #phone{
    padding: 10px 180px 10px 10px;
  }
  #fix{
      height:48px;
  }
</style>



    <body>
    <div class="wrapper">
       <div class="form-wrapper">
         <h1>Create Account</h1>
       <form  method="post">
          <div  class="form-group <?php echo (!empty($username_err)) ? 'has-error' : ''; ?>">
          <label htmlFor="username">UserName:</label>
          <input type="text" placeholder="UserName" id="username" name="username" required onBlur="validName()"/>
          <span id="errormessage1" class="help-block"><?php echo $username_err; ?></span>
          </div>

          <div  class="form-group <?php echo (!empty($phone_err)) ? 'has-error' : ''; ?>">
            <label htmlFor="username">Phone No:</label>
            <div class="input-group-prepend">
              <span id="fix" class="input-group-text">+92</span>
              <input type="text" placeholder="Phone No" id="phone" name="phone" required onBlur="validPhone()" />
             
            </div>
            <span id="errormessage2"class="help-block"><?php echo $phone_err; ?></span>
          </div>

          <div class="form-group <?php echo (!empty($email_err)) ? 'has-error' : ''; ?>">
          <label htmlFor="email">Email:</label>
          <input type="email" placeholder="Email" id="email"  name="email" />
          <span id="errormessage" class="help-block"><?php echo $email_err; ?></span>
          </div>
         
          <div class="form-group <?php echo (!empty($password_err)) ? 'has-error' : ''; ?>" >
          <label htmlFor="password">Password:</label>
          <input type="password" placeholder="Password"  id="password"name="password"  /> 
          <span id="errormessage"class="help-block"><?php echo $password_err; ?></span>
          </div>

          <div class="form-group <?php echo (!empty($confirm_password_err)) ? 'has-error' : ''; ?>">
          <label htmlFor="confirm pass">Confirm Password:</label>
          <input type="password" placeholder="Password" id="CPass" name="confirm_password" />
          <span id="errormessage"class="help-block"><?php echo $confirm_password_err; ?></span>
          </div> 
         
          <div>
          <button class="btn btn-outline-primary"  id="btnn" name="txtbutton" ><a >Submit</a></button>
            
          </div>
           
          <p id="p">Already have an account? <a href="login1.php">Login here</a>.</p>
        
         </form>  
       </div> 
    </div>
</body>
</html>



